import { google } from "googleapis";
import * as readline from "readline";

const CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;

if (!CLIENT_ID || !CLIENT_SECRET) {
  console.error("環境変数 GOOGLE_CLIENT_ID と GOOGLE_CLIENT_SECRET を設定してください");
  process.exit(1);
}

const auth = new google.auth.OAuth2(CLIENT_ID, CLIENT_SECRET, "urn:ietf:wg:oauth:2.0:oob");

const authUrl = auth.generateAuthUrl({
  access_type: "offline",
  scope: ["https://www.googleapis.com/auth/calendar.readonly", "https://www.googleapis.com/auth/calendar.events"],
});

console.log("\n以下のURLをブラウザで開いて、Googleアカウントで認証してください:\n");
console.log(authUrl);
console.log("\n認証後に表示されたコードを入力してください:");

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
rl.question("> ", async (code) => {
  rl.close();
  const { tokens } = await auth.getToken(code.trim());
  console.log("\n✅ GOOGLE_REFRESH_TOKEN:", tokens.refresh_token);
  console.log("\nこの値をLambdaの環境変数 GOOGLE_REFRESH_TOKEN に設定してください");
});
